declare module '*.frag' {
    const value: string;

    export default value;
}

declare module '*.vert' {
    const value: string;

    export default value;
}

declare module 'es6-promise-polyfill'

declare namespace NodeJS {
    interface Global {
        performance: Performance|{[x: string]: any};
        requestAnimationFrame: (callback: FrameRequestCallback) => NodeJS.Timeout;
        cancelAnimationFrame: (handle: number) => void;
    }
}
