# @pixi/constants

## Installation

```bash
npm install @pixi/constants
```

## Usage

```js
import * as constants from '@pixi/constants';
```