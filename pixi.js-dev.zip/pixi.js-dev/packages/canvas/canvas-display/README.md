# @pixi/canvas-display

## Installation

```bash
npm install @pixi/canvas-display
```

## Usage

```js
import '@pixi/canvas-display';
```