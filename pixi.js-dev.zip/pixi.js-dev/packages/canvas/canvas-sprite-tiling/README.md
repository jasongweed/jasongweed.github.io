# @pixi/canvas-sprite-tiling

## Installation

```bash
npm install @pixi/canvas-sprite-tiling
```

## Usage

```js
import '@pixi/canvas-sprite-tiling';
```