import { Application } from './Application';
import { ResizePlugin } from './ResizePlugin';

Application.registerPlugin(ResizePlugin);

export * from './Application';
