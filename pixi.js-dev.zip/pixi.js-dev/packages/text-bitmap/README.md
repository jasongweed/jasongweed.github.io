# @pixi/text-bitmap

## Installation

```bash
npm install @pixi/text-bitmap
```

## Usage

```js
import { BitmapFontLoader } from '@pixi/text-bitmap';
import { Loader } from '@pixi/loaders';
Loader.registerPlugin(BitmapFontLoader);
```
