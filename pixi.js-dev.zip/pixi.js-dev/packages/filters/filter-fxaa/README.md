# @pixi/filter-fxaa

## Installation

```bash
npm install @pixi/filter-fxaa
```

## Usage

```js
import '@pixi/filter-fxaa';
```